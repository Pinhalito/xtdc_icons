#!/bin/bash
#
#######################
#    ^...^  `^...^´   #
#   /_o,o_\ /_O,O_\   #
#   |):::(| |):::(|   #
# ====" "=====" "==== #
#         TdC         #
#      1998-2026      #
#######################
#
# Toca das Corujas
# Códigos Binários,
# Funções de Onda e
# Teoria do Orbital Molecular Inc.
# Unidade Barão Geraldo CX
#

ln -s scalable 128x128
ln -s scalable 12x12
ln -s scalable 12x12@2
ln -s scalable 12x12@3
ln -s scalable 16x16
ln -s scalable 16x16@2
ln -s scalable 16x16@3
ln -s scalable 22x22
ln -s scalable 22x22@2
ln -s scalable 22x22@3
ln -s scalable 24x24
ln -s scalable 24x24@2
ln -s scalable 24x24@3
ln -s scalable 256x256
ln -s scalable 32x32
ln -s scalable 32x32@2
ln -s scalable 32x32@3
ln -s scalable 48x48
ln -s scalable 48x48@2
ln -s scalable 48x48@3
ln -s scalable 512x512
ln -s scalable 64x64
ln -s scalable 8x8
ln -s scalable 8x8@2
ln -s scalable 8x8@3
ln -s scalable 96x96
gtk-update-icon-cache /usr/share/icons/xtdc_svg/
